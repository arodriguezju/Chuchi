var Converter = require("csvtojson").Converter;

var Promise = require('es6-promise').Promise;

var jsonfile = require('jsonfile'); 


parseStoreDataAndWriteToFile = function(){
    
    var converter = new Converter({
        delimiter: ';'
    });
    
    
    require("fs").createReadStream("./resources/Valora_stores_eng.csv").pipe(converter);

    //end_parsed will be emitted once parsing finished 
    converter.on("end_parsed", function (jsonArray) {
        jsonfile.writeFile('stores.json', jsonArray, function (err) {
            console.error(err);
        });
        
    });
    
   
    
}


parseStoreDataAndWriteToFile();
