var Converter = require("csvtojson").Converter;

var Promise = require('es6-promise').Promise;

var jsonfile = require('jsonfile'); 


parseStoreData = function(){
    
    var converter = new Converter({
        delimiter: ';'
    });
    
    return new Promise(function(resolve, reject){
        require("fs").createReadStream("./resources/Valora_stores_eng.csv").pipe(converter);
    
        //end_parsed will be emitted once parsing finished 
        converter.on("end_parsed", function (jsonArray) {
            jsonfile.writeFile('stores.json', jsonArray, function (err) {
                console.error(err);
            });
            //resolve(jsonArray);
        });
    
    });
    
    
    
}

var NodeGeocoder = require('node-geocoder');
 
var options = {
  provider: 'google',
 
  // Optional depending on the providers 
  httpAdapter: 'https', // Default 
  apiKey: 'AIzaSyBTyV-mvb4yM_xyIm_3gIN42aaW4gMTpnY', 
  formatter: null         // 'gpx', 'string', ... 
};


mapAddressToGeolocation = function(address) {
    var geocoder = NodeGeocoder(options);
 
//    // Using callback 
//    geocoder.geocode(address, function(err, res) {
//      //console.log(res[0]);
//        if (res[0] != null && res[0] != undefined){
//            console.log(res[0].latitude +", "+ res[0].longitude);
//        }
//    });
 
//     Or using Promise 
    return new Promise(function(resolve, reject){
        
        geocoder.geocode(address)
          .then(function(res) {
            //console.log(res);
            if (res[0] != null && res[0] != undefined){
                var geoInfo = {
                    "lat": res[0].latitude,
                    "lon": res[0].longitude
                }; 
                //console.log(geoInfo);
                resolve(geoInfo);
            }
            else {
                var geoInfo = {
                    "lat": undefined,
                    "lon": undefined
                }
                resolve(geoInfo);
            }
          })
          .catch(function(err) {
            console.log(err);
          });
        
        
    });
    

}

parseStoreData();

//mapAddressToGeolocation();

performLoad = function(){
    
    var storesWithGeoInfoList = [];

    var stores = parseStoreData().then(function(data){
        console.log(data);
        
        for (var i=0; i<=data.length; i++){
            var address = data[i].Street+", "+data[i].ZIP+", "+data[i].City;
            console.log(address);
            mapAddressToGeolocation(address).then(function(val){
                var storeWithGeoInfo = {
                    "id" : data[i].Store,
                    "geoInfo": val
                };
                storesWithGeoInfoList.put(storeWithGeoInfo);
            });
        }
        
        console.log(storesWithGeoInfoList);
        
    });
    

    //console.log(stores);
    //mapAddressToGeolocation();
}

//performLoad();