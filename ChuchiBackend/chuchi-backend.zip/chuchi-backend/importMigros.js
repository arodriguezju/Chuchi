var Promise = require('es6-promise').Promise;

var jsonfile = require('jsonfile'); 


var firebase = require('firebase');

var GeoFire = require('geofire');


firebase.initializeApp({
    apiKey: "AIzaSyAF0JHyoExAdIXEqd1_wxxyxxl-XVdBfz0",
    databaseURL: "https://chuchi-face6.firebaseio.com"
});    

// Generate a random Firebase location
var firebaseRef = firebase.database().ref('stores');


// Create a new GeoFire instance at the random Firebase location
var geoFire = new GeoFire(firebaseRef);

getStoreData = function(){
    var file = './resources/migros.json';
    return new Promise(function(resolve, reject){
       jsonfile.readFile(file, function(err, obj) {
          //console.log(obj);
           resolve(obj);
       }); 
    });
}


uploadStores = function(){

    getStoreData().then(function(obj){
        
        if (obj != undefined && obj != null){
            var d = obj.stores;
            for (var i=0; i< 100; i++){
                var geo = [
                    d[i].location.geo.lat, d[i].location.geo.lon
                ];
                console.log(d[i].id);
                console.log(geo);
                importToFirebase(d[i].id, geo);
            }
        }
    });
    
    
}


function importToFirebase(storeId, location){
    
    console.log("import location for store " + storeId +", "+ location);
      // Initialize the Firebase SDK

 
      // Set the initial locations of the fish in GeoFire

    geoFire.set(storeId.toString(), location).then(function() {
      console.log("store" + storeId + " initially set to [" + location + "]");
    }); 

}

uploadStores();