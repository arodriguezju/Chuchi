var express = require('express');

var Promise = require('es6-promise').Promise;

var jsonfile = require('jsonfile')


function callValoraForItemAndStore(itemId, storeId) {
    
    if (itemId == undefined || itemId == null){
        console.log('No itemId set. Fallback to: 9002975301268');
        itemId = 9002975301268;
    }
    
    if (storeId == undefined || storeId == null){
        console.log('No storeId set. Fallback to: 18406');
        storeId = 18406;
    }
    
    return new Promise(function(resolve, reject){
        var requestUrl = "https://backend.scango.ch/api/v01/items/find-by-ean/?ean="+itemId+"&format=json&retail_store_id="+storeId+"";
    
        console.log(requestUrl);

        var request = require('request'),
        username = "HackZurich",
        password = "mKw%VY<7.Yb8D!G-",
        url= requestUrl,
        auth = "Basic " + new Buffer(username + ":" + password).toString("base64");

        request(
            {
                url : url,
                headers : {
                    "Authorization" : auth
                }
            },
            function (error, response, body) {
                if (error || response.statusCode != 200) {
                    console.log('Something went wrong! use fallback - mock data');
                    
                    fallbackItem = {
                      "pk": 41171,
                      "valora_item_id": "9002975301268",
                      "name": "HEIDA Provins Valais",
                      "age_limit": 18,
                      "current_price": {
                        "pk": 40678,
                        "retail_store_id": "18406",
                        "price": 11.25,
                        "price_valid_from": "2015-03-16T01:00:00",
                        "price_valid_until": null
                      },
                      "item_group": "F02022"
                    };
                        
                        
                    resolve(fallbackItem);

                }
                
                console.log('body: ', body);
                resolve(body);
            }
        );   
    });
    
}

findStoreName = function(storeId){
    var file = 'stores.json';
    return new Promise(function(resolve, reject){
       jsonfile.readFile(file, function(err, obj) {
            var store = undefined;
            for (var i = 0; i< obj.length; i++){
                if (obj[i].Store == storeId){
                    store = obj[i].Name;
                }
            }
           resolve(store);
       }); 
    });

};

startServer = function(){
    var app = express();
    
    app.get('/items/:itemId/:storeId', function(req, res) {
        //eg 9002975301268
        var itemId = req.params.itemId;
        console.log('received itemId: ' + itemId);
        //eg 18406
        var storeId = req.params.storeId;
        console.log('received storeId: ' + storeId);
    
        callValoraForItemAndStore(itemId, storeId).then(function(data){
            
            if (data != undefined && data != null){
                findStoreName(storeId).then(function(storeName){
                    var result = {
                        "item": data,
                        "storeName": storeName
                    };
                    
                    console.log('store name: ' + storeName);
                    res.json(result);
                    console.log(result);
                    return result;
                });
                
                
            }
            else {
                res.json({item: data});
                
                return data;
            }
                
        }
        );
        
    
    
    });
    
//    app.get('/items/');
    
    app.listen(3000);
    
};

startServer();

