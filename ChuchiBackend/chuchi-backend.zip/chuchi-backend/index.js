var express = require('express');

var Promise = require('es6-promise').Promise;



function callValoraForItemAndStore(itemId, storeId) {
    
    return new Promise(function(resolve, reject){
        var requestUrl = "https://backend.scango.ch/api/v01/items/find-by-ean/?ean="+itemId+"&format=json&retail_store_id="+storeId+"";
    
        console.log(requestUrl);

        var request = require('request'),
        username = "HackZurich",
        password = "mKw%VY<7.Yb8D!G-",
        url= requestUrl,
        auth = "Basic " + new Buffer(username + ":" + password).toString("base64");

        request(
            {
                url : url,
                headers : {
                    "Authorization" : auth
                }
            },
            function (error, response, body) {
                console.log(body);
                resolve(body);
            }
        );   
    });
    
}

startServer = function(){
    var app = express();
    
    app.get('/items/:itemId/:storeId', function(req, res) {
        //eg 9002975301268
        var itemId = req.params.itemId;
        console.log('received itemId: ' + itemId);
        //eg 18406
        var storeId = req.params.storeId;
        console.log('received storeId: ' + storeId);
    
        callValoraForItemAndStore(itemId, storeId).then(function(data){
            res.json({item: data});
            }
        );
    
    });
    
//    app.get('/items/');
    
    app.listen(3000);
    
};

startServer();

