README

example url for calling valora API

http://localhost:3000/items/9002975301268/18406

http://localhost:3000/items/itemId/storeId